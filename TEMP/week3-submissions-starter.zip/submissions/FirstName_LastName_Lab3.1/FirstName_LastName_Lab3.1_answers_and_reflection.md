# Lab 3.1: answers and reflection

Name:

## Before you submit, this folder should contain

Replace `FirstName_LastName` with your own name in this folder's name and in every file name, for example `Jane_Smith_Lab3.1`. Use exactly these names.

- Your terminal recording(s) for this lab, copied from `../terminal-logs/`
- `FirstName_LastName_Lab3.1_screenshot_legacy_span.png`: a Dynatrace trace showing the `legacy-template-store` span inside your request's waterfall
- `FirstName_LastName_Lab3.1_answers_and_reflection.md`: this file, completed

Remove your Dynatrace token from anything you submit. Zip this folder as `FirstName_LastName_Lab3.1.zip` and upload it to the Student Lab Submission Repo before you end your Skillable session.

---

## Step 1: the manifest

- What `legacy.yaml` tells you about how the template store will behave:

- What it doesn't tell you, that you'd want to know before depending on it:

## Step 3: three views

| View  | What it told you | What it couldn't tell you |
|-------|------------------|---------------------------|
| Logs  |                  |                           |
| Trace |                  |                           |
| Probe |                  |                           |

- Your baseline from the probe: requests, throughput per second, p50 and p95:

## Step 4: three scored failure modes

| # | Failure mode | Effect on the customer | S | L | D | RPN | Evidence for each score |
|---|--------------|------------------------|---|---|---|-----|-------------------------|
| 1 | Caption renderer slow | | | | | | |
| 2 | Caption renderer error | | | | | | |
| 3 | Legacy template store not running | | | | | | |

- Which comes first under the severity-first rule, and is it the same order as RPN?

## Discuss

What might the other `RC=` codes be, and where would you look to find out?


## What Went Well / What Didn't Go Well

A few sentences under each heading is enough.

### What Went Well

- Which steps worked first time, and why you think they did:

- What you'd question in the `fetchTemplate` code, now that you've read it:

### What Didn't Go Well

- Anything that failed or confused you, the actual error you saw, and how you fixed it:

- If nothing failed, the one score in Step 4 you were least sure of, and what evidence would settle it:
