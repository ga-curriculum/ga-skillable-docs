# Lab 3.2: answers and reflection

Name:

## Before you submit, this folder should contain

Replace `FirstName_LastName` with your own name in this folder's name and in every file name, for example `Jane_Smith_Lab3.2`. Use exactly these names.

- Your terminal recording(s) for this lab, copied from `../terminal-logs/`
- `FirstName_LastName_register.csv`: your register, sorted by the severity-first rule, with your top three marked
- `FirstName_LastName_Lab3.2_screenshot_availability.png`: your Module 2 dashboard during Step 2, showing your availability tiles
- `FirstName_LastName_Lab3.2_screenshot_slow_minute.png`: your Module 2 dashboard across the slow minute from Step 6, showing your latency tiles
- `FirstName_LastName_Lab3.2_answers_and_reflection.md`: this file, completed

Remove your Dynatrace token from anything you submit. Zip this folder as `FirstName_LastName_Lab3.2.zip` and upload it to the Student Lab Submission Repo before you end your Skillable session.

---

## Step 1: the sweep

- Your seven sweep lines:

```
(paste here)
```

- The knee, the capacity, what latency did beyond the knee, and where other RC codes appeared, with their HTTP status:

- Your Little's Law calculation, and the number of transactions the store runs at once:

- The difference between the template store's 48 line and your API's 48 line:

## Step 2: the signals that lie

| Signal | What it said | What was actually happening |
|---|---|---|
| Health check | | |
| Pod status | | |
| Your API's status code | | |
| Your availability SLO | | |

## Step 6: the long run

- The clock times of the slow lines, and what your dashboard and alerts did in that minute:

## Step 7: calibration and top three

- One failure mode where your scores differed from your partner's by more than three points, the evidence behind the difference, and what you changed:

- Your top three, each with one sentence on why:

## Discuss

What did your API ignore in the template store's answer, and what would it have taken to notice?

Did RPN alone put any of your `Review regardless` rows outside your top five, and what does that tell you?


## What Went Well / What Didn't Go Well

A few sentences under each heading is enough.

### What Went Well

- Which measurement surprised you most, and what it changed in your register:

- How the facilitator and scribe roles worked for you:

### What Didn't Go Well

- Anything that failed or confused you, the actual error you saw, and how you fixed it:

- If nothing failed, the row in your register you're least confident about, and what evidence would settle it:
