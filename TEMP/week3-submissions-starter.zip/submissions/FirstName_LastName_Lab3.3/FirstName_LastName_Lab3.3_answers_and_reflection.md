# Lab 3.3: answers and reflection

Name:

## Before you submit, this folder should contain

Replace `FirstName_LastName` with your own name in this folder's name and in every file name, for example `Jane_Smith_Lab3.3`. Use exactly these names.

- Your terminal recording(s) for this lab, copied from `../terminal-logs/`
- `FirstName_LastName_Lab3.3_screenshot_rc_counts.png`: your Step 3 notebook result, with calls counted by `legacy.rc` and `legacy.fallback`
- `FirstName_LastName_Lab3.3_answers_and_reflection.md`: this file, completed

Remove your Dynatrace token from anything you submit. Zip this folder as `FirstName_LastName_Lab3.3.zip` and upload it to the Student Lab Submission Repo before you end your Skillable session.

---

## Step 1: three mitigation specifications

| Part | Mitigation 1 | Mitigation 2 | Mitigation 3 |
|---|---|---|---|
| Failure mode (register ID) | | | |
| Score it lowers, from and to | | | |
| The change | | | |
| How you'll know it worked | | | |
| The risk it brings | | | |
| Owner | | | |

## Step 3: before and after

| Run | good/s | p95 ms | HTTP codes | RC codes |
|---|---|---|---|---|
| Lab 3.2, API at 16 | | | | |
| Lab 3.3, API at 16 | | | | |
| Lab 3.2, API at 48 | | | | |
| Lab 3.3, API at 48 | | | | |
| Lab 3.3, API at 48, timeout only | | | | |

## Step 3: re-scored rows

| Register ID | Old S / L / D | New S / L / D | Evidence | Any new risk the change created |
|---|---|---|---|---|
| | | | | |

## Discuss

For the batch window, what could you change, and what could only its owners change?

Is a stale template, marked `stale`, a success from the customer's side?


## What Went Well / What Didn't Go Well

A few sentences under each heading is enough.

### What Went Well

- Which measurement best showed the mitigation working, and why that one:

- Whether the timeout-only result matched what you expected:

### What Didn't Go Well

- Anything that failed or confused you, the actual error you saw, and how you fixed it:

- If nothing failed, the one part of the mitigation you'd least trust in production, and why:
