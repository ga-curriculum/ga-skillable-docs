# Lab 3.4: answers and reflection

Name:

## Before you submit, this folder should contain

Replace `FirstName_LastName` with your own name in this folder's name and in every file name, for example `Jane_Smith_Lab3.4`. Use exactly these names.

- `FirstName_LastName_Lab3.4_screenshot_chart.png`: your chart of `logon_success_pct`, `logon_attempts_per_s` and `customers_trying_per_s` against time
- `FirstName_LastName_register.csv`: your register, with any rows added in Step 3 marked `yes` in the **New in Lab 3.4** column
- `FirstName_LastName_Lab3.4_answers_and_reflection.md`: this file, completed

This lab has no cluster work, so no terminal recording is needed.

Remove your Dynatrace token from anything you submit. Zip this folder as `FirstName_LastName_Lab3.4.zip` and upload it to the Student Lab Submission Repo before you end your Skillable session.

---

## Step 1: timeline

| Time | Event | Metric at that time |
|---|---|---|
| | | |

- Time to detect, time to recover, and time to the right team, each with the two times you used:

## Step 2: causal chain

| Layer | What happened | The number | How you got it |
|---|---|---|---|
| Business event | | | |
| Customer behaviour | | | |
| Requests at the front door | | | |
| Fan-out | | | |
| Amplifiers | | | |
| The fixed-capacity hop | | | |
| What the customer saw | | | |

- PROF01's capacity during and after the batch, with your working:

- Peak demand before and after amplifiers, and as a multiple of capacity:

- The retry multiplier at the peak:

- What the autoscaler did to the calls waiting for PROF01:

- The share of useful work at the peak, and why the rest wasn't useful:

- Why the service didn't recover when the batch finished:

## Discuss

Why was reducing demand the faster lever?

## Step 3: your register against the incident

| In the incident | Your register row, or "none" | Added now? |
|---|---|---|
| A fixed-capacity component behind services that scale | | |
| Batch work taking capacity on an unknown schedule | | |
| A failure answered as success | | |
| Callers giving up while the dependency carried on | | |
| Retries multiplying load | | |
| Health checks and a synthetic test passing | | |

- The row Wrenfield's register should have ranked highest, and the score they most likely got wrong:

## Step 4: blameless summary

(Write six to eight sentences here.)


## What Went Well / What Didn't Go Well

A few sentences under each heading is enough.

### What Went Well

- Which number in the causal chain most changed how you saw the incident:

- Where your own register already had it covered:

### What Didn't Go Well

- Anything that confused you in the pack, and how you resolved it:

- One thing you'd want in the pack that isn't there, and what you'd use it for:
