# Lab 3.5: answers and reflection

Name:

## Before you submit, this folder should contain

Replace `FirstName_LastName` with your own name in this folder's name and in every file name, for example `Jane_Smith_Lab3.5`. Use exactly these names.

- Your terminal recording(s) for this lab, copied from `../terminal-logs/`
- `FirstName_LastName_Lab3.5_screenshot_open_and_closed.png`: your Module 2 availability tiles across both halves of Step 1, fail open and fail closed
- `FirstName_LastName_Lab3.5_answers_and_reflection.md`: this file, completed

Remove your Dynatrace token from anything you submit. Zip this folder as `FirstName_LastName_Lab3.5.zip` and upload it to the Student Lab Submission Repo before you end your Skillable session.

---

## Step 1: open and closed

| Mode | HTTP codes | good/s | What the template said | What your availability SLO did |
|---|---|---|---|---|
| Fail open | | | | |
| Fail closed | | | | |

| Journey | Fail open or closed? | Why |
|---|---|---|
| Meme template | | |
| Bank balance on the home screen | | |
| Payee name check before a payment | | |
| Marketing offers banner | | |

## Discuss

Was Wrenfield's £0.00 failing open or closed, and what should it have done?

## Step 2: SRE or CRE

| # | SRE, CRE or both | Fit for use? Fit for purpose? | One line of reasoning |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |
| 6 | | | |

## Step 3: capacity-risk table

| Hop | At once | Time per unit | Gives up after | Capacity | Demand at 06:45, without retries | Demand as it arrived | Headroom | How known | When full |
|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | |

- The first hop to run out, and at how many customers per second, with and without the batch:

- The least well-known hop, and your question for its owner:

- The hop whose behaviour when full hurt customers most, and why:

## Discuss

Who would own a table like this in your organisation?


## What Went Well / What Didn't Go Well

A few sentences under each heading is enough.

### What Went Well

- What surprised you most about your SLO during the fail-open half of Step 1:

- Which row of the capacity table was easiest to fill in, and why:

### What Didn't Go Well

- Anything that failed or confused you, the actual error you saw, and how you fixed it:

- If nothing failed, the row of the capacity table you're least confident about, and what would settle it:
