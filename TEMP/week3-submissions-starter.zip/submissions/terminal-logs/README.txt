Your terminal recordings for Week 3 are saved here automatically.

When you submit a lab, copy the recordings from that lab into the lab's folder.
